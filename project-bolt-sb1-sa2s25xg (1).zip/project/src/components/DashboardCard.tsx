import React from 'react';
import { AlertTriangle, TrendingUp, Droplet } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  status: 'normal' | 'warning' | 'critical';
  type: 'pollutant' | 'nutrient' | 'chemical';
  trend?: 'up' | 'down' | 'stable';
}

const DashboardCard: React.FC<DashboardCardProps> = ({ title, value, status, type, trend }) => {
  const getStatusColor = () => {
    switch (status) {
      case 'normal':
        return 'bg-green-100 text-green-800';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800';
      case 'critical':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-700">{title}</h3>
        {status === 'critical' && (
          <AlertTriangle className="h-5 w-5 text-red-500" />
        )}
      </div>
      <div className="flex items-baseline justify-between">
        <p className="text-3xl font-bold">{value}</p>
        {trend && (
          <div className="flex items-center">
            <TrendingUp className={`h-4 w-4 ${trend === 'up' ? 'text-red-500' : 'text-green-500'}`} />
          </div>
        )}
      </div>
      <div className={`mt-4 inline-flex items-center px-3 py-1 rounded-full text-sm ${getStatusColor()}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </div>
    </div>
  );
};

export default DashboardCard;