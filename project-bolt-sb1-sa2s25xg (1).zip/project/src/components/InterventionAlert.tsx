import React from 'react';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface InterventionAlertProps {
  type: 'warning' | 'action';
  message: string;
  recommendation: string;
}

const InterventionAlert: React.FC<InterventionAlertProps> = ({ type, message, recommendation }) => {
  return (
    <div className={`rounded-lg p-4 mb-4 ${
      type === 'warning' ? 'bg-yellow-50 border-yellow-200' : 'bg-blue-50 border-blue-200'
    } border`}>
      <div className="flex items-center">
        {type === 'warning' ? (
          <AlertCircle className="h-5 w-5 text-yellow-500 mr-3" />
        ) : (
          <CheckCircle className="h-5 w-5 text-blue-500 mr-3" />
        )}
        <div>
          <h4 className="text-sm font-medium mb-1">
            {type === 'warning' ? 'Warning' : 'Recommended Action'}
          </h4>
          <p className="text-sm text-gray-600">{message}</p>
          <p className="text-sm font-medium mt-2">Recommendation: {recommendation}</p>
        </div>
      </div>
    </div>
  );
};

export default InterventionAlert;