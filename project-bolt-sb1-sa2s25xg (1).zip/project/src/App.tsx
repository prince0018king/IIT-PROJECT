import React, { useState, useEffect } from 'react';
import { Droplet, Activity, FlaskRound as Flask } from 'lucide-react';
import DashboardCard from './components/DashboardCard';
import InterventionAlert from './components/InterventionAlert';
import TrendChart from './components/TrendChart';

// Generate mock historical data for the last 24 hours
const generateHistoricalData = (baseValue: number, volatility: number) => {
  const data = [];
  const now = new Date();
  for (let i = 24; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 3600000).toISOString();
    const randomFactor = 1 + (Math.random() - 0.5) * volatility;
    data.push({
      timestamp,
      value: Number((baseValue * randomFactor).toFixed(2))
    });
  }
  return data;
};

function App() {
  const [currentTime, setCurrentTime] = useState(new Date());

  // Generate mock data for different parameters
  const heavyMetalsData = generateHistoricalData(0.85, 0.3);
  const nitrogenData = generateHistoricalData(12.3, 0.4);
  const phosphorusData = generateHistoricalData(2.1, 0.2);
  const dissolvedOxygenData = generateHistoricalData(5.2, 0.5);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Droplet className="h-8 w-8 text-blue-600" />
              <h1 className="ml-3 text-2xl font-bold text-gray-900">Wastewater Management Dashboard</h1>
            </div>
            <div className="text-sm text-gray-500">
              Last updated: {currentTime.toLocaleTimeString()}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <DashboardCard
            title="Heavy Metals (mg/L)"
            value="0.85"
            status="warning"
            type="pollutant"
            trend="up"
          />
          <DashboardCard
            title="Nitrogen Levels (mg/L)"
            value="12.3"
            status="critical"
            type="nutrient"
            trend="up"
          />
          <DashboardCard
            title="Phosphorus (mg/L)"
            value="2.1"
            status="normal"
            type="nutrient"
          />
          <DashboardCard
            title="pH Level"
            value="6.8"
            status="normal"
            type="chemical"
          />
          <DashboardCard
            title="Dissolved Oxygen (mg/L)"
            value="5.2"
            status="warning"
            type="chemical"
            trend="down"
          />
          <DashboardCard
            title="Total Suspended Solids (mg/L)"
            value="156"
            status="warning"
            type="pollutant"
          />
        </div>

        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <TrendChart
            title="Heavy Metals Concentration"
            data={heavyMetalsData}
            dataKey="value"
            color="#ef4444"
            unit="mg/L"
          />
          <TrendChart
            title="Nitrogen Levels"
            data={nitrogenData}
            dataKey="value"
            color="#3b82f6"
            unit="mg/L"
          />
          <TrendChart
            title="Phosphorus Levels"
            data={phosphorusData}
            dataKey="value"
            color="#10b981"
            unit="mg/L"
          />
          <TrendChart
            title="Dissolved Oxygen"
            data={dissolvedOxygenData}
            dataKey="value"
            color="#8b5cf6"
            unit="mg/L"
          />
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Real-time Interventions</h2>
          <div className="space-y-4">
            <InterventionAlert
              type="warning"
              message="Elevated nitrogen levels detected in discharge point A-3"
              recommendation="Increase aeration in treatment basin 2 and adjust nutrient removal process"
            />
            <InterventionAlert
              type="action"
              message="Heavy metals concentration approaching threshold"
              recommendation="Implement additional filtration and verify industrial discharge compliance"
            />
            <InterventionAlert
              type="warning"
              message="Dissolved oxygen levels below optimal range"
              recommendation="Check aeration system performance and increase oxygen supply"
            />
          </div>
        </div>

        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Water Quality Overview</h2>
          <div className="prose max-w-none">
            <p className="text-gray-600">
              The current wastewater quality indicators show several areas requiring attention. 
              Nitrogen levels have exceeded acceptable limits, potentially indicating issues with 
              the biological treatment process. Heavy metals concentration, while within legal limits, 
              shows an upward trend that requires monitoring. Dissolved oxygen levels are lower than 
              optimal, which may affect the efficiency of biological treatment processes.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;